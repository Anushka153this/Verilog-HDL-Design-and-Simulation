`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////
// Author : Anushka Gope
////////////////////////////////////////////////////////////////////////////////
module Moore_FSM(
    input clk,
    input rst,
    input x,
    output reg y
);
    reg [2:0] state, next_state;
    parameter S0 = 3'b000,
    S1 = 3'b001,
    S2 = 3'b010,
    S3 = 3'b011,
    S4 = 3'b100;
    // State register
    always @(posedge clk or posedge rst) begin
        if (rst)
            state <= S0;
        else
            state <= next_state;
    end
    // Next state logic
    always @(*) begin
        case(state)
            S0: begin
                if (x == 1) next_state = S1;
                else
                    next_state = S0;
            end
            S1: begin
                if (x == 0) next_state = S2;
                else
                    next_state = S1;
            end
            S2: begin
                if (x == 1) next_state = S3;
                else
                    next_state = S0;
            end
            S3: begin
                if (x == 1) next_state = S4;
                else
                    next_state = S2;
            end
            S4: begin
                if (x == 0) next_state = S0;
                else
                    next_state = S1;
            end
            default: next_state = S0;
        endcase
    end
    // Output logic
    always @(*) begin
        if (state == S4) y = 1;
        else
            y = 0;
    end
endmodule
