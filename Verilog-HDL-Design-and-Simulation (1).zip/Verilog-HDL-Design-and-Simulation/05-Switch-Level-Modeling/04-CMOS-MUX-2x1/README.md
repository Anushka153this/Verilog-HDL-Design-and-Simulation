# CMOS 2:1 Multiplexer

> **Topic 05: Switch-Level Modeling** · Author: Anushka Gope

## Purpose

Models a 2:1 multiplexer using CMOS transmission gates.

## Working Principle

An inverter generates `sbar` from `s`. Two `cmos` transmission gates connect `in_a` (conducting when `s = 0`) and `in_b` (conducting when `s = 1`) to `out`. The testbench applies `in_a = 1`, `in_b = 0` and toggles `s` (two vectors).

## Interface

### Inputs

| Port | Width | Description |
|---|---|---|
| `in_a` | 1 | Data input selected when s = 0 |
| `in_b` | 1 | Data input selected when s = 1 |
| `s` | 1 | Select |

### Outputs

| Port | Width | Description |
|---|---|---|
| `out` | 1 | Selected output |

## Source Files

| Type | File | Top module | Origin |
|---|---|---|---|
| Design | [`cmos_mux_2x1.v`](cmos_mux_2x1.v) | `cmos_mux_2x1` | Original |
| Testbench | [`cmos_mux_2x1_tb.v`](cmos_mux_2x1_tb.v) | `cmos_mux_2x1_tb_v` | Original |

## Simulation Results

**ModelSim waveform of `cmos_mux_2x1_tb_v`**

![ModelSim waveform of `cmos_mux_2x1_tb_v`](Simulation-Results/waveform.png)

The waveform shows `s`, `in_a`, `in_b` and `out` over the 200 ns run.

See [`Simulation-Results/README.md`](Simulation-Results/README.md) for details.

## Known Issues and Resolutions

Original code is preserved exactly (in `Original-Source/` where a file was replaced). Problems are documented rather than silently corrected.

None found by static review of the supplied code.

All issues are collected in [`Known-Issues.md`](../../Known-Issues.md).

## Running the Simulation

**Compile status (static review):** Compiles on its own by static reading.

```bash
# Example with Icarus Verilog (indicative; not executed while preparing this repository)
iverilog -o sim cmos_mux_2x1.v cmos_mux_2x1_tb.v
vvp sim
```

The original results were produced with the tools used in the lab (ModelSim-style waveform windows and Synopsys / Xilinx report formats appear in the source). No simulation was re-run while preparing this portfolio.
