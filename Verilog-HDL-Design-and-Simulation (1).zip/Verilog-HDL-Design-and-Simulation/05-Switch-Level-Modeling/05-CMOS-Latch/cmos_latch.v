`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////
// Author : Anushka Gope
////////////////////////////////////////////////////////////////////////////////
module cmos_latch (
    input D,
    input EN,
    output Q,
    output Qbar
);
    supply1 VDD;
    supply0 GND;
    wire n1, n2;
    cmos (n1, D, EN, ~EN);
    pmos (Q, VDD, n1);
    nmos (Q, GND, n1);
    cmos (n2, Q, ~EN, EN);
    pmos (Qbar, VDD, Q);
    nmos (Qbar, GND, Q);
endmodule
