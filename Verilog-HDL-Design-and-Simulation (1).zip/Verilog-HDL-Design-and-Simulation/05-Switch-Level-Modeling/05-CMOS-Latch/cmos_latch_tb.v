`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////
// Author : Anushka Gope
////////////////////////////////////////////////////////////////////////////////
module cmos_latch_tb_v;
    reg D;
    reg EN;
    wire Q;
    wire Qbar;
    cmos_latch uut (
        .D(D),
        .EN(EN),
        .Q(Q),
        .Qbar(Qbar)
    );
    initial begin
        $monitor("Time=%0t | EN=%b | D=%b | Q=%b | Qbar=%b",
            $time, EN, D, Q, Qbar);
        EN = 0;
        D  = 0;
        #10;
        EN = 1;
        D  = 1;
        #10;
        D = 0;
        #10;
        EN = 0;
        D  = 1;
        #10;
        D = 0;
        #10;
        EN = 1;
        D  = 0;
        #10;
        D = 1;
        #10;
        EN = 0;
        #10;
        $finish;
    end
endmodule
