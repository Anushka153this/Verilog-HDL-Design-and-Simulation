# CMOS Latch

> **Topic 05: Switch-Level Modeling** · Author: Anushka Gope

## Purpose

Attempts a CMOS level-sensitive latch built from a transmission gate and inverters.

## Working Principle

A transmission gate (`cmos`) passes `D` to internal node `n1` while `EN = 1`; an inverter (PMOS/NMOS pair) produces `Q` from `n1`, and a second inverter produces `Qbar` from `Q`. A second transmission gate, driven by the opposite enable polarity, is also instantiated on `Q`.

## Interface

### Inputs

| Port | Width | Description |
|---|---|---|
| `D` | 1 | Data input |
| `EN` | 1 | Enable (transparent when high) |

### Outputs

| Port | Width | Description |
|---|---|---|
| `Q` | 1 | Latch output |
| `Qbar` | 1 | Complement of Q |

## Source Files

| Type | File | Top module | Origin |
|---|---|---|---|
| Design | [`cmos_latch.v`](cmos_latch.v) | `cmos_latch` | Original |
| Testbench | [`cmos_latch_tb.v`](cmos_latch_tb.v) | `cmos_latch_tb_v` | Original |

## Simulation Results

**ModelSim waveform of `cmos_latch_tb_v`**

![ModelSim waveform of `cmos_latch_tb_v`](Simulation-Results/waveform.png)

The waveform shows `D`, `EN`, `Q` and `Qbar`. `Q` and `Qbar` are drawn partly in red and their value column reads `StX`, i.e. **unknown (X)** during the capture. The source does not say whether this was expected.

See [`Simulation-Results/README.md`](Simulation-Results/README.md) for details.

## Known Issues and Resolutions

Original code is preserved exactly (in `Original-Source/` where a file was replaced). Problems are documented rather than silently corrected.

- By inspection, the feedback transmission gate drives a separate net `n2` that is never connected back to `n1`, so no storage loop exists. When `EN = 0` the node `n1` is left floating. This matches the unknown values seen in the waveform. The code was left unchanged.

All issues are collected in [`Known-Issues.md`](../../Known-Issues.md).

## Running the Simulation

**Compile status (static review):** Compiles on its own by static reading.

```bash
# Example with Icarus Verilog (indicative; not executed while preparing this repository)
iverilog -o sim cmos_latch.v cmos_latch_tb.v
vvp sim
```

The original results were produced with the tools used in the lab (ModelSim-style waveform windows and Synopsys / Xilinx report formats appear in the source). No simulation was re-run while preparing this portfolio.
