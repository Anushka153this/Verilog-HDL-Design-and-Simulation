# Simulation Results: CMOS Latch

> Topic 05: Switch-Level Modeling · Author: Anushka Gope

The images below were extracted from the original lab documents. They are genuine captures, not regenerated.

### `waveform.png`

ModelSim waveform of `cmos_latch_tb_v`.

![ModelSim waveform of `cmos_latch_tb_v`](waveform.png)

## What the images show

The waveform shows `D`, `EN`, `Q` and `Qbar`. `Q` and `Qbar` are drawn partly in red and their value column reads `StX`, i.e. **unknown (X)** during the capture. The source does not say whether this was expected.

## Not provided in the source

- `simulation-output.png` (console / transcript output): the source documents contain no console captures, so this file has intentionally not been created.

## Notes

- By inspection, the feedback transmission gate drives a separate net `n2` that is never connected back to `n1`, so no storage loop exists. When `EN = 0` the node `n1` is left floating. This matches the unknown values seen in the waveform. The code was left unchanged.
