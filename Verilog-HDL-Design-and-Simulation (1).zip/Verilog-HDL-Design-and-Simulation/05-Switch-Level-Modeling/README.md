# 05. Switch-Level Modeling

> Part of [Verilog-HDL-Design-and-Simulation](../README.md) · Author: Anushka Gope

## Overview

Transistor-level (switch-level) models written with Verilog `pmos`, `nmos` and `cmos` primitives: inverter, NAND, NOR, 2:1 multiplexer, latch and a 5-input Boolean function.

## Designs

| # | Design | Design file | Testbench | Waveform | Reports |
|---|---|---|---|---|---|
| 01 | [CMOS Inverter](01-CMOS-Inverter/README.md) | Original | Original | Yes | - |
| 02 | [CMOS NAND Gate](02-CMOS-NAND/README.md) | Original | Original | Yes | - |
| 03 | [CMOS NOR Gate](03-CMOS-NOR/README.md) | Original | Original | Yes | - |
| 04 | [CMOS 2:1 Multiplexer](04-CMOS-MUX-2x1/README.md) | Original | Original | Yes | - |
| 05 | [CMOS Latch](05-CMOS-Latch/README.md) | Original | Original | Yes | - |
| 06 | [CMOS Boolean Function (5 inputs)](06-CMOS-Boolean-Function/README.md) | Original | Original | Yes | - |

"Original" = extracted from the lab documents (formatting only). "Corrected" and "Added" = newly prepared files merged in later (not recovered originals, not simulated); replaced originals are kept in each design's `Original-Source/` folder. "Reference (new)" = newly written to stand in for missing source. "Pending" = not available. "Unverified" = image labels do not match the design.

## Folder Layout

```text
05-Switch-Level-Modeling/
├── README.md
├── 01-CMOS-Inverter/
├── 02-CMOS-NAND/
├── 03-CMOS-NOR/
├── 04-CMOS-MUX-2x1/
├── 05-CMOS-Latch/
├── 06-CMOS-Boolean-Function/
```

Each design folder contains its own `README.md`, the Verilog source, the testbench and a `Simulation-Results/` folder.
