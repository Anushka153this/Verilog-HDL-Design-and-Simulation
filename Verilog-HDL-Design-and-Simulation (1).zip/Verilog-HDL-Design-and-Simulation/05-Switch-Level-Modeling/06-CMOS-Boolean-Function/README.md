# CMOS Boolean Function (5 inputs)

> **Topic 05: Switch-Level Modeling** · Author: Anushka Gope

## Purpose

Attempts to build a 5-input Boolean function from CMOS pull-up/pull-down transistors.

## Working Principle

The structure computes the intermediate terms `DE`, `BC` and `BE` (each a NAND stage followed by an inverter), then a final stage over `A`, `DE`, `BC`, `BE` followed by an output inverter. From this gate structure the intended function is **Y = A + D·E + B·C + B·E**. The testbench drives the five inputs and runs for 60 ns.

## Interface

### Inputs

| Port | Width | Description |
|---|---|---|
| `A` | 1 | Input A |
| `B` | 1 | Input B |
| `C` | 1 | Input C |
| `D` | 1 | Input D |
| `E` | 1 | Input E |

### Outputs

| Port | Width | Description |
|---|---|---|
| `Y` | 1 | Output |

## Source Files

| Type | File | Top module | Origin |
|---|---|---|---|
| Design | [`boolean_cmos.v`](boolean_cmos.v) | `boolean_cmos` | Original |
| Testbench | [`boolean_cmos_tb.v`](boolean_cmos_tb.v) | `cmos_boolean_tb_v` | Original |

## Simulation Results

**ModelSim waveform of `cmos_boolean_tb_v`**

![ModelSim waveform of `cmos_boolean_tb_v`](Simulation-Results/waveform.png)

The waveform shows the five inputs and `Y` over the 60 ns run. The `Y` trace is partly drawn in red, the colour ModelSim uses for unknown values.

See [`Simulation-Results/README.md`](Simulation-Results/README.md) for details.

## Known Issues and Resolutions

Original code is preserved exactly (in `Original-Source/` where a file was replaced). Problems are documented rather than silently corrected.

- By inspection, the final stage connects four PMOS transistors in parallel to `vdd` and four NMOS transistors in parallel to `gnd` on the same node (`Y_bar`). A valid complementary CMOS gate would need the pull-up and pull-down networks to be duals (series versus parallel). With this arrangement, differing inputs make the PMOS and NMOS devices fight, which simulation can show as X. The code was left unchanged.

All issues are collected in [`Known-Issues.md`](../../Known-Issues.md).

## Running the Simulation

**Compile status (static review):** Compiles on its own by static reading.

```bash
# Example with Icarus Verilog (indicative; not executed while preparing this repository)
iverilog -o sim boolean_cmos.v boolean_cmos_tb.v
vvp sim
```

The original results were produced with the tools used in the lab (ModelSim-style waveform windows and Synopsys / Xilinx report formats appear in the source). No simulation was re-run while preparing this portfolio.
