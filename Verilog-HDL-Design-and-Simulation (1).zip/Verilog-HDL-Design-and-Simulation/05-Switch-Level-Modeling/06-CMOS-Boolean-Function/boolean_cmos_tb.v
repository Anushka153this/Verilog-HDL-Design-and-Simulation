`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////
// Author : Anushka Gope
///////////////////////////////////////////////////////////////////////////////
module cmos_boolean_tb_v;
    reg A, B, C, D, E;
    wire Y;
    boolean_cmos uut (
        .A(A),
        .B(B),
        .C(C),
        .D(D),
        .E(E),
        .Y(Y)
    );
    initial begin
        $monitor("A=%b B=%b C=%b D=%b E=%b --> Y=%b",
            A, B, C, D, E, Y);
        A=0; B=0; C=0; D=0; E=0; #10;
        A=0; B=0; C=0; D=1; E=1; #10;
        A=0; B=1; C=1; D=0; E=0; #10;
        A=0; B=1; C=0; D=0; E=1; #10;
        A=1; B=0; C=0; D=0; E=0; #10;
        A=1; B=1; C=1; D=1; E=1; #10;
        $finish;
    end
endmodule
