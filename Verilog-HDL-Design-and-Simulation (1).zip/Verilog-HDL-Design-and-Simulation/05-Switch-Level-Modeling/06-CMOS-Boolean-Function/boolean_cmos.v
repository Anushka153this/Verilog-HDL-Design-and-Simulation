`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////
// Author : Anushka Gope
////////////////////////////////////////////////////////////////////////////////
module boolean_cmos (
    input A, B, C, D, E,
    output Y
);
    supply1 VDD;
    supply0 GND;
    wire nA, nB, nC, nD, nE;
    wire DE_bar, BC_bar, BE_bar;
    wire DE, BC, BE;
    wire Y_bar;
    pmos (nA, VDD, A);
    nmos (nA, GND, A);
    pmos (nB, VDD, B);
    nmos (nB, GND, B);
    pmos (nC, VDD, C);
    nmos (nC, GND, C);
    pmos (nD, VDD, D);
    nmos (nD, GND, D);
    pmos (nE, VDD, E);
    nmos (nE, GND, E);
    wire de_n1;
    pmos (DE_bar, VDD, D);
    pmos (DE_bar, VDD, E);
    nmos (DE_bar, de_n1, D);
    nmos (de_n1, GND, E);
    pmos (DE, VDD, DE_bar);
    nmos (DE, GND, DE_bar);
    wire bc_n1;
    pmos (BC_bar, VDD, B);
    pmos (BC_bar, VDD, C);
    nmos (BC_bar, bc_n1, B);
    nmos (bc_n1, GND, C);
    pmos (BC, VDD, BC_bar);
    nmos (BC, GND, BC_bar);
    wire be_n1;
    pmos (BE_bar, VDD, B);
    pmos (BE_bar, VDD, E);
    nmos (BE_bar, be_n1, B);
    nmos (be_n1, GND, E);
    pmos (BE, VDD, BE_bar);
    nmos (BE, GND, BE_bar);
    pmos (Y_bar, VDD, A);
    pmos (Y_bar, VDD, DE);
    pmos (Y_bar, VDD, BC);
    pmos (Y_bar, VDD, BE);
    nmos (Y_bar, GND, A);
    nmos (Y_bar, GND, DE);
    nmos (Y_bar, GND, BC);
    nmos (Y_bar, GND, BE);
    pmos (Y, VDD, Y_bar);
    nmos (Y, GND, Y_bar);
endmodule
