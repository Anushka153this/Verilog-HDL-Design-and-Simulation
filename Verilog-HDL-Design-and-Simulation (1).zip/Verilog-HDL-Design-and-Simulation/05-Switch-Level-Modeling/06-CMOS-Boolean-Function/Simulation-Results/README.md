# Simulation Results: CMOS Boolean Function (5 inputs)

> Topic 05: Switch-Level Modeling · Author: Anushka Gope

The images below were extracted from the original lab documents. They are genuine captures, not regenerated.

### `waveform.png`

ModelSim waveform of `cmos_boolean_tb_v`.

![ModelSim waveform of `cmos_boolean_tb_v`](waveform.png)

## What the images show

The waveform shows the five inputs and `Y` over the 60 ns run. The `Y` trace is partly drawn in red, the colour ModelSim uses for unknown values.

## Not provided in the source

- `simulation-output.png` (console / transcript output): the source documents contain no console captures, so this file has intentionally not been created.

## Notes

- By inspection, the final stage connects four PMOS transistors in parallel to `vdd` and four NMOS transistors in parallel to `gnd` on the same node (`Y_bar`). A valid complementary CMOS gate would need the pull-up and pull-down networks to be duals (series versus parallel). With this arrangement, differing inputs make the PMOS and NMOS devices fight, which simulation can show as X. The code was left unchanged.
